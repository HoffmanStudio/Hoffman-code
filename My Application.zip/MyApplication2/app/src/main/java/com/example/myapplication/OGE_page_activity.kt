package com.example.myapplication
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class OGE_page_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.oge)
    var buttonCross: ImageButton = findViewById(R.id.imageButton)
    buttonCross.setOnClickListener {
    val intent2 = Intent(this, MainActivity::class.java)
    startActivity(intent2)
    }
    }
}