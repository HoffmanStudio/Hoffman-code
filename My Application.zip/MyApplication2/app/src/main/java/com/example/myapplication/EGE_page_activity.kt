package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class EGE_page_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ege)
    val buttonClose: ImageButton = findViewById(R.id.imageButton2)
    buttonClose.setOnClickListener {
        val intent4 = Intent(this, MainActivity::class.java)
        startActivity(intent4)
    }
    }
}